import 'package:flutter/material.dart';
import 'dart:async';

final ValueNotifier<ThemeMode> globalThemeNotifier =
    ValueNotifier(ThemeMode.dark);
final ValueNotifier<String> globalLangNotifier = ValueNotifier('ar');
String globalUserName = '';

// ==========================================
// نظام الترجمة الشامل
// ==========================================
class T {
  static final Map<String, Map<String, String>> _data = {
    'ar': {
      'appTitle': 'منظم المهام الذكي',
      'cancel': 'إلغاء',
      'save': 'حفظ',
      'add': 'إضافة',
      'edit': 'تعديل',
      'delete': 'حذف',
      'confirm': 'تأكيد',
      'open': 'فتح',
      'language': 'اللغة',
      'goHome': 'الرئيسية',
      'welcome': 'مرحباً بك!',
      'enterName': 'ما هو اسمك؟',
      'startUsing': 'بدء الاستخدام',
      'homeWelcome': 'الرئيسية الترحيبية',
      'practicalTasksFull': 'المهام العملية والتوقيت',
      'walletFull': 'المحفظة والمديونيات',
      'notesFull': 'المفكرة والملاحظات',
      'manage': 'إدارة المهام والوقت بكفاءة',
      'home': 'الرئيسية',
      'practicalTasks': 'المهام العملية',
      'wallet': 'المحفظة والمديونيات',
      'notes': 'المفكرة الشخصية',
      'trash': 'سلة المهملات',
      'helloUser': 'أهلاً بك',
      'helloUserName': 'أهلاً بك يا',
      'smartOrganizer': 'منظمك الذكي',
      'todayWisdom': 'حكمة اليوم للإنجاز',
      'practicalTasksCount': 'المهام العملية',
      'financialSummary': 'الملخص المالي',
      'notesCount': 'الملاحظات',
      'addTask': 'إضافة مهمة عملية جديدة',
      'noTasks': 'لا توجد مهام عملية حالياً',
      'addTaskTitle': 'إضافة مهمة عملية',
      'editTaskTitle': 'تعديل مهمة عملية',
      'taskName': 'عنوان المهمة',
      'taskDesc': 'الوصف أو التفاصيل',
      'duration': 'المدة الزمنية للإنجاز:',
      'hour': 'ساعة',
      'day': 'يوم',
      'timeExpired': 'انتهى الوقت!',
      'remaining': 'متبقي:',
      'daysUnit': 'يوم',
      'hoursUnit': 'ساعة',
      'minutesUnit': 'دقيقة',
      'walletLog': 'سجل المحفظة',
      'debtsManage': 'إدارة المديونيات',
      'netBalance': 'صافي الرصيد المتبقي',
      'currency': 'ريال',
      'credit': 'دائن',
      'debit': 'مدين',
      'type': 'النوع:',
      'statement': 'البيان...',
      'amount': 'المبلغ',
      'cat1': 'صافي الراتب',
      'cat2': 'أموال أخرى (دخل)',
      'cat3': 'أقساط ومديونيات',
      'cat4': 'مصروف عادي',
      'debtLabel': 'المديونية:',
      'debtHint': 'اختر ليتم الخصم منها',
      'editEntry': 'تعديل القيد',
      'statementLabel': 'البيان',
      'amountLabel': 'المبلغ',
      'installmentPaid': 'تم تسجيل القسط وخصمه من المديونية',
      'totalRemaining': 'إجمالي الديون المتبقية',
      'totalDebts': 'إجمالي الديون',
      'totalPaid': 'المسدد',
      'addDebt': 'إضافة مديونية جديدة',
      'addDebtTitle': 'إضافة مديونية جديدة',
      'editDebtTitle': 'تعديل مديونية',
      'debtName': 'اسم الجهة أو الدين (مثال: قسط سيارة)',
      'debtTotal': 'إجمالي مبلغ الدين',
      'debtRemain': 'المتبقي:',
      'debtPaid': 'المسدد:',
      'payNow': 'سداد قسط الآن',
      'payInstallment': 'سداد قسط:',
      'payAmountNow': 'المبلغ المسدد الآن',
      'confirmPay': 'تأكيد السداد',
      'debtCleared': 'تم سداد المديونية بالكامل 🎉',
      'paySuccess': 'تم سداد القسط وخصمه من المديونية وإضافته للمحفظة بنجاح.',
      'newNote': 'ملاحظة جديدة',
      'sortByImportance': 'فرز حسب الأهمية',
      'newNoteTitle': 'ملاحظة جديدة',
      'editNoteTitle': 'تعديل الملاحظة',
      'noteTitle': 'العنوان...',
      'noteContent': 'الملاحظة...',
      'setPassword': 'تعيين كلمة المرور',
      'password': 'كلمة المرور',
      'confirmPassword': 'تأكيد كلمة المرور',
      'passwordMismatch': 'كلمة المرور غير متطابقة!',
      'noteLocked': 'الملاحظة مقفلة',
      'enterPassword': 'أدخل كلمة المرور',
      'wrongPassword': 'كلمة المرور خاطئة!',
      'emptyTrash': 'تفريغ السلة',
      'trashEmpty': 'سلة المهملات فارغة',
      'noTitle': '(بدون عنوان)',
      'itemType': 'النوع:',
      'restore': 'استرجاع فوري',
      'deletePermanent': 'حذف نهائي',
      'restoreSuccess': 'تم استرجاع العنصر إلى قسمه بنجاح ودون تأخير!',
      'typeTask': 'مهمة عملية',
      'typeNote': 'ملاحظة',
      'typeExpense': 'عملية مالية',
      'typeDebt': 'مديونية',
      'q1': 'إن لم تبدأ اليوم، فلن تنتهي غداً. السر يكمن دائماً في البداية.',
      'q2': 'إنجازك اليوم هو الحجر الأساس لبناء نجاحات الغد العظيمة.',
      'q3': 'لا تنتظر الظروف المثالية لتنجز، اصنع ظروفك الخاصة وانطلق.',
      'q4': 'التخطيط الجيد والخطوات الصغيرة المستمرة تصنع فارقاً مهولاً.',
      'q5': 'المفاتيح الأساسية للإنتاجية: التركيز المطلق وتحديد الأولويات.',
      'installmentPrefix': 'قسط:',
      'installmentPayPrefix': 'سداد قسط:',
    },
    'fr': {
      'appTitle': 'Organisateur Intelligent',
      'cancel': 'Annuler',
      'save': 'Enregistrer',
      'add': 'Ajouter',
      'edit': 'Modifier',
      'delete': 'Supprimer',
      'confirm': 'Confirmer',
      'open': 'Ouvrir',
      'language': 'Langue',
      'goHome': 'Accueil',
      'welcome': 'Bienvenue !',
      'enterName': 'Quel est votre nom ?',
      'startUsing': 'Commencer',
      'homeWelcome': 'Accueil principal',
      'practicalTasksFull': 'Tâches & Horaires',
      'walletFull': 'Portefeuille & Dettes',
      'notesFull': 'Notes & Mémos',
      'manage': 'Gérer les tâches efficacement',
      'home': 'Accueil',
      'practicalTasks': 'Tâches pratiques',
      'wallet': 'Portefeuille & Dettes',
      'notes': 'Carnet personnel',
      'trash': 'Corbeille',
      'helloUser': 'Bonjour',
      'helloUserName': 'Bonjour',
      'smartOrganizer': 'Votre organisateur',
      'todayWisdom': 'Sagesse du jour',
      'practicalTasksCount': 'Tâches',
      'financialSummary': 'Résumé financier',
      'notesCount': 'Notes',
      'addTask': 'Ajouter une nouvelle tâche',
      'noTasks': 'Aucune tâche pour le moment',
      'addTaskTitle': 'Ajouter une tâche',
      'editTaskTitle': 'Modifier la tâche',
      'taskName': 'Titre de la tâche',
      'taskDesc': 'Description ou détails',
      'duration': 'Durée de réalisation :',
      'hour': 'heure',
      'day': 'jour',
      'timeExpired': 'Temps écoulé !',
      'remaining': 'Restant :',
      'daysUnit': 'j',
      'hoursUnit': 'h',
      'minutesUnit': 'min',
      'walletLog': 'Registre',
      'debtsManage': 'Gestion des dettes',
      'netBalance': 'Solde net restant',
      'currency': '€',
      'credit': 'Crédit',
      'debit': 'Débit',
      'type': 'Type :',
      'statement': 'Libellé...',
      'amount': 'Montant',
      'cat1': 'Salaire net',
      'cat2': 'Autres revenus',
      'cat3': 'Versements & dettes',
      'cat4': 'Dépense courante',
      'debtLabel': 'Dette :',
      'debtHint': 'Choisir pour déduire',
      'editEntry': 'Modifier l\'entrée',
      'statementLabel': 'Libellé',
      'amountLabel': 'Montant',
      'installmentPaid': 'Versement enregistré et déduit de la dette',
      'totalRemaining': 'Total des dettes restantes',
      'totalDebts': 'Total des dettes',
      'totalPaid': 'Payé',
      'addDebt': 'Ajouter une nouvelle dette',
      'addDebtTitle': 'Ajouter une dette',
      'editDebtTitle': 'Modifier la dette',
      'debtName': 'Nom de la dette (ex: prêt auto)',
      'debtTotal': 'Montant total de la dette',
      'debtRemain': 'Restant :',
      'debtPaid': 'Payé :',
      'payNow': 'Payer un versement',
      'payInstallment': 'Versement :',
      'payAmountNow': 'Montant versé maintenant',
      'confirmPay': 'Confirmer le paiement',
      'debtCleared': 'Dette entièrement remboursée 🎉',
      'paySuccess': 'Versement confirmé et déduit de la dette avec succès.',
      'newNote': 'Nouvelle note',
      'sortByImportance': 'Trier par importance',
      'newNoteTitle': 'Nouvelle note',
      'editNoteTitle': 'Modifier la note',
      'noteTitle': 'Titre...',
      'noteContent': 'Note...',
      'setPassword': 'Définir un mot de passe',
      'password': 'Mot de passe',
      'confirmPassword': 'Confirmer le mot de passe',
      'passwordMismatch': 'Les mots de passe ne correspondent pas !',
      'noteLocked': 'Note verrouillée',
      'enterPassword': 'Entrer le mot de passe',
      'wrongPassword': 'Mot de passe incorrect !',
      'emptyTrash': 'Vider la corbeille',
      'trashEmpty': 'La corbeille est vide',
      'noTitle': '(sans titre)',
      'itemType': 'Type :',
      'restore': 'Restaurer',
      'deletePermanent': 'Supprimer définitivement',
      'restoreSuccess': 'Élément restauré avec succès !',
      'typeTask': 'Tâche pratique',
      'typeNote': 'Note',
      'typeExpense': 'Transaction financière',
      'typeDebt': 'Dette',
      'q1':
          'Si vous ne commencez pas aujourd\'hui, vous ne finirez pas demain.',
      'q2':
          'Votre accomplissement d\'aujourd\'hui est la base du succès de demain.',
      'q3': 'N\'attendez pas les conditions idéales, créez les vôtres.',
      'q4':
          'Une bonne planification et de petites étapes régulières font une grande différence.',
      'q5':
          'Les clés de la productivité : concentration totale et priorisation.',
      'installmentPrefix': 'Versement :',
      'installmentPayPrefix': 'Paiement :',
    },
    'en': {
      'appTitle': 'Smart Task Manager',
      'cancel': 'Cancel',
      'save': 'Save',
      'add': 'Add',
      'edit': 'Edit',
      'delete': 'Delete',
      'confirm': 'Confirm',
      'open': 'Open',
      'language': 'Language',
      'goHome': 'Home',
      'welcome': 'Welcome!',
      'enterName': 'What is your name?',
      'startUsing': 'Get Started',
      'homeWelcome': 'Home Screen',
      'practicalTasksFull': 'Tasks & Schedule',
      'walletFull': 'Wallet & Debts',
      'notesFull': 'Notes & Memos',
      'manage': 'Manage tasks & time efficiently',
      'home': 'Home',
      'practicalTasks': 'Practical Tasks',
      'wallet': 'Wallet & Debts',
      'notes': 'Personal Notebook',
      'trash': 'Trash',
      'helloUser': 'Hello',
      'helloUserName': 'Hello',
      'smartOrganizer': 'Your Smart Organizer',
      'todayWisdom': "Today's Wisdom",
      'practicalTasksCount': 'Tasks',
      'financialSummary': 'Financial Summary',
      'notesCount': 'Notes',
      'addTask': 'Add New Task',
      'noTasks': 'No practical tasks yet',
      'addTaskTitle': 'Add Practical Task',
      'editTaskTitle': 'Edit Practical Task',
      'taskName': 'Task Title',
      'taskDesc': 'Description or Details',
      'duration': 'Completion Duration:',
      'hour': 'hour',
      'day': 'day',
      'timeExpired': 'Time Expired!',
      'remaining': 'Remaining:',
      'daysUnit': 'd',
      'hoursUnit': 'h',
      'minutesUnit': 'min',
      'walletLog': 'Wallet Log',
      'debtsManage': 'Manage Debts',
      'netBalance': 'Net Remaining Balance',
      'currency': '\$',
      'credit': 'Credit',
      'debit': 'Debit',
      'type': 'Type:',
      'statement': 'Description...',
      'amount': 'Amount',
      'cat1': 'Net Salary',
      'cat2': 'Other Income',
      'cat3': 'Installments & Debts',
      'cat4': 'Regular Expense',
      'debtLabel': 'Debt:',
      'debtHint': 'Select to deduct from',
      'editEntry': 'Edit Entry',
      'statementLabel': 'Description',
      'amountLabel': 'Amount',
      'installmentPaid': 'Installment recorded and deducted from debt',
      'totalRemaining': 'Total Remaining Debts',
      'totalDebts': 'Total Debts',
      'totalPaid': 'Paid',
      'addDebt': 'Add New Debt',
      'addDebtTitle': 'Add New Debt',
      'editDebtTitle': 'Edit Debt',
      'debtName': 'Debt name (e.g. car loan)',
      'debtTotal': 'Total Debt Amount',
      'debtRemain': 'Remaining:',
      'debtPaid': 'Paid:',
      'payNow': 'Pay Installment Now',
      'payInstallment': 'Pay Installment:',
      'payAmountNow': 'Amount Paid Now',
      'confirmPay': 'Confirm Payment',
      'debtCleared': 'Debt fully repaid 🎉',
      'paySuccess': 'Installment paid and deducted from debt successfully.',
      'newNote': 'New Note',
      'sortByImportance': 'Sort by Importance',
      'newNoteTitle': 'New Note',
      'editNoteTitle': 'Edit Note',
      'noteTitle': 'Title...',
      'noteContent': 'Note...',
      'setPassword': 'Set Password',
      'password': 'Password',
      'confirmPassword': 'Confirm Password',
      'passwordMismatch': 'Passwords do not match!',
      'noteLocked': 'Note Locked',
      'enterPassword': 'Enter Password',
      'wrongPassword': 'Wrong password!',
      'emptyTrash': 'Empty Trash',
      'trashEmpty': 'Trash is empty',
      'noTitle': '(no title)',
      'itemType': 'Type:',
      'restore': 'Restore',
      'deletePermanent': 'Delete Permanently',
      'restoreSuccess': 'Item restored to its section successfully!',
      'typeTask': 'Practical Task',
      'typeNote': 'Note',
      'typeExpense': 'Financial Transaction',
      'typeDebt': 'Debt',
      'q1': 'If you don\'t start today, you won\'t finish tomorrow.',
      'q2':
          'Today\'s achievement is the foundation for tomorrow\'s great successes.',
      'q3':
          'Don\'t wait for perfect conditions, create your own and move forward.',
      'q4': 'Good planning and consistent small steps make a huge difference.',
      'q5': 'The keys to productivity: absolute focus and setting priorities.',
      'installmentPrefix': 'Installment:',
      'installmentPayPrefix': 'Payment:',
    },
  };

  static String s(String key) {
    final lang = globalLangNotifier.value;
    return _data[lang]?[key] ?? _data['ar']?[key] ?? key;
  }

  static List<String> get quotes =>
      [s('q1'), s('q2'), s('q3'), s('q4'), s('q5')];
  static List<String> get categories =>
      [s('cat1'), s('cat2'), s('cat3'), s('cat4')];
}

void main() {
  runApp(const MyTasksApp());
}

String getCurrentFormattedDate() {
  final now = DateTime.now();
  final hour = now.hour == 0 ? 12 : (now.hour > 12 ? now.hour - 12 : now.hour);
  final period = now.hour >= 12 ? 'م' : 'ص';
  final minute = now.minute.toString().padLeft(2, '0');
  return '${now.year}/${now.month}/${now.day} - $hour:$minute $period';
}

final List<Map<String, dynamic>> globalPracticalTasks = [];
final List<Map<String, dynamic>> globalExpenses = [];
final List<Map<String, dynamic>> globalDebts = [];
final List<Map<String, dynamic>> globalNotes = [];
final List<Map<String, dynamic>> globalTrash = [];

class MyTasksApp extends StatelessWidget {
  const MyTasksApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: globalLangNotifier,
      builder: (context, lang, _) {
        return ValueListenableBuilder<ThemeMode>(
          valueListenable: globalThemeNotifier,
          builder: (context, currentMode, _) {
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              title: T.s('appTitle'),
              themeMode: currentMode,
              theme: ThemeData(
                brightness: Brightness.light,
                scaffoldBackgroundColor: const Color(0xFFF8FAFC),
                primaryColor: const Color(0xFF4F46E5),
                cardColor: Colors.white,
                colorScheme: const ColorScheme.light(
                  primary: Color(0xFF4F46E5),
                  secondary: Color(0xFF10B981),
                  surface: Colors.white,
                  background: Color(0xFFF8FAFC),
                ),
                fontFamily: 'Cairo',
              ),
              darkTheme: ThemeData(
                brightness: Brightness.dark,
                scaffoldBackgroundColor: const Color(0xFF0F172A),
                primaryColor: const Color(0xFF6366F1),
                cardColor: const Color(0xFF1E293B),
                colorScheme: const ColorScheme.dark(
                  primary: Color(0xFF6366F1),
                  secondary: Color(0xFF34D399),
                  surface: Color(0xFF1E293B),
                  background: Color(0xFF0F172A),
                ),
                fontFamily: 'Cairo',
              ),
              home: const DashboardScreen(),
            );
          },
        );
      },
    );
  }
}

// ==========================================
// الشاشة الرئيسية (Dashboard)
// ==========================================
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (globalUserName.isEmpty) _showNameDialog();
    });
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() => setState(() {});

  Future<void> _showNameDialog() async {
    TextEditingController nameCtrl = TextEditingController();
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => ValueListenableBuilder<String>(
        valueListenable: globalLangNotifier,
        builder: (ctx, lang, _) => Directionality(
          textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
          child: AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Text(T.s('welcome'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // --- قائمة اختيار اللغة مدمجة ---
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(15),
                      border:
                          Border.all(color: const Color(0xFF4F46E5), width: 1),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: lang,
                        isExpanded: true,
                        icon: const Icon(Icons.language,
                            color: Color(0xFF4F46E5)),
                        items: const [
                          DropdownMenuItem(
                              value: 'ar',
                              child: Text('العربية 🇸🇦',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold))),
                          DropdownMenuItem(
                              value: 'en',
                              child: Text('English 🇺🇸',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold))),
                          DropdownMenuItem(
                              value: 'fr',
                              child: Text('Français 🇫🇷',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold))),
                        ],
                        onChanged: (value) {
                          if (value != null) globalLangNotifier.value = value;
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: nameCtrl,
                    decoration: InputDecoration(
                      labelText: T.s('enterName'),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15)),
                      prefixIcon:
                          const Icon(Icons.person, color: Color(0xFF4F46E5)),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4F46E5),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: () {
                  if (nameCtrl.text.trim().isNotEmpty) {
                    setState(() => globalUserName = nameCtrl.text.trim());
                    Navigator.pop(context);
                  }
                },
                child: Text(T.s('startUsing'),
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
      ),
    );
  }

  void _navigateToTab(int index) => setState(() => _selectedIndex = index);

  List<String> get _titles => [
        T.s('home'),
        T.s('practicalTasks'),
        T.s('wallet'),
        T.s('notes'),
        T.s('trash'),
      ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final List<Widget> tabs = [
      WelcomeTab(onNavigate: _navigateToTab),
      const PracticalTasksTab(),
      const FinancesTab(),
      const NotesTab(),
      const TrashTab(),
    ];

    return Directionality(
      textDirection: globalLangNotifier.value == 'ar'
          ? TextDirection.rtl
          : TextDirection.ltr,
      child: Scaffold(
        resizeToAvoidBottomInset: true, // حل مشكلة الشريط الأصفر بشكل رئيسي
        appBar: AppBar(
          title: Text(_titles[_selectedIndex],
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          centerTitle: true,
          elevation: 0,
          backgroundColor:
              isDark ? const Color(0xFF1E293B) : const Color(0xFF4F46E5),
          actions: [
            if (_selectedIndex != 0)
              Tooltip(
                message: T.s('goHome'),
                child: InkWell(
                  onTap: () => setState(() => _selectedIndex = 0),
                  borderRadius: BorderRadius.circular(20),
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(20),
                        border:
                            Border.all(color: Colors.white.withOpacity(0.35)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.home_rounded,
                              size: 15, color: Colors.white),
                          const SizedBox(width: 4),
                          Text(T.s('goHome'),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            IconButton(
              icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
              onPressed: () => globalThemeNotifier.value =
                  isDark ? ThemeMode.light : ThemeMode.dark,
            ),
          ],
        ),
        drawer: _buildDrawer(isDark),
        body: tabs[_selectedIndex],
      ),
    );
  }

  Widget _buildDrawer(bool isDark) {
    return Drawer(
      backgroundColor:
          isDark ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC),
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isDark
                    ? [const Color(0xFF1E293B), const Color(0xFF334155)]
                    : [const Color(0xFF4F46E5), const Color(0xFF6366F1)],
              ),
            ),
            accountName: Text(
              globalUserName.isEmpty ? T.s('helloUser') : globalUserName,
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Colors.white),
            ),
            accountEmail: Text(T.s('manage'),
                style: const TextStyle(color: Colors.white70)),
            // --- اللوغو الاحترافي بدلاً من الصورة العادية ---
            currentAccountPicture: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white24,
                border: Border.all(color: Colors.white, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  )
                ],
              ),
              child: const Center(
                child: Icon(Icons.auto_awesome, size: 45, color: Colors.white),
              ),
            ),
          ),
          _buildDrawerItem(0, T.s('homeWelcome'), Icons.dashboard, isDark),
          _buildDrawerItem(
              1, T.s('practicalTasksFull'), Icons.business_center, isDark),
          _buildDrawerItem(
              2, T.s('walletFull'), Icons.account_balance_wallet, isDark),
          _buildDrawerItem(3, T.s('notesFull'), Icons.note_alt, isDark),
          const Divider(),
          _buildDrawerItem(4, T.s('trash'), Icons.delete, isDark),
          const Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Icon(Icons.language,
                    size: 18,
                    color: isDark
                        ? const Color(0xFF6366F1)
                        : const Color(0xFF4F46E5)),
                const SizedBox(width: 8),
                Text(T.s('language'),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: isDark ? Colors.white70 : Colors.black54)),
              ],
            ),
          ),
          const SizedBox(height: 6),
          ValueListenableBuilder<String>(
            valueListenable: globalLangNotifier,
            builder: (context, currentLang, _) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  _buildLangChip('ar', 'ع', 'عربي', currentLang, isDark),
                  const SizedBox(width: 8),
                  _buildLangChip('fr', 'Fr', 'Français', currentLang, isDark),
                  const SizedBox(width: 8),
                  _buildLangChip('en', 'En', 'English', currentLang, isDark),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(int index, String title, IconData icon, bool isDark) {
    final bool isSelected = _selectedIndex == index;
    final Color activeColor =
        isDark ? const Color(0xFF6366F1) : const Color(0xFF4F46E5);
    return ListTile(
      leading: Icon(icon,
          color: isSelected
              ? activeColor
              : (isDark ? Colors.white60 : Colors.black54)),
      title: Text(title,
          style: TextStyle(
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? activeColor : null)),
      selected: isSelected,
      onTap: () {
        _navigateToTab(index);
        Navigator.pop(context);
      },
    );
  }

  Widget _buildLangChip(String code, String symbol, String label,
      String currentLang, bool isDark) {
    final bool isActive = currentLang == code;
    final Color activeColor =
        isDark ? const Color(0xFF6366F1) : const Color(0xFF4F46E5);
    return Expanded(
      child: GestureDetector(
        onTap: () {
          globalLangNotifier.value = code;
          setState(() {});
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeInOut,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isActive
                ? activeColor
                : (isDark ? const Color(0xFF1E293B) : Colors.white),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isActive
                  ? activeColor
                  : (isDark ? Colors.white24 : Colors.grey.shade300),
              width: isActive ? 2 : 1,
            ),
            boxShadow: isActive
                ? [
                    BoxShadow(
                        color: activeColor.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 3))
                  ]
                : null,
          ),
          child: Column(
            children: [
              Text(symbol,
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      color: isActive
                          ? Colors.white
                          : (isDark ? Colors.white60 : Colors.black54))),
              const SizedBox(height: 2),
              Text(label,
                  style: TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.w600,
                      color: isActive
                          ? Colors.white70
                          : (isDark ? Colors.white38 : Colors.black38)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 1. شاشة الترحيب
// ==========================================
class WelcomeTab extends StatefulWidget {
  final Function(int) onNavigate;
  const WelcomeTab({Key? key, required this.onNavigate}) : super(key: key);
  @override
  State<WelcomeTab> createState() => _WelcomeTabState();
}

class _WelcomeTabState extends State<WelcomeTab> {
  late String selectedQuote;

  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
    _pickQuote();
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() {
    setState(() => _pickQuote());
  }

  void _pickQuote() {
    final q = List<String>.from(T.quotes)..shuffle();
    selectedQuote = q.first;
  }

  double _calculateNetTotal() {
    double credit = globalExpenses
        .where((i) => i['isCredit'] == true)
        .fold(0.0, (s, i) => s + i['amount']);
    double debit = globalExpenses
        .where((i) => i['isCredit'] == false)
        .fold(0.0, (s, i) => s + i['amount']);
    return credit - debit;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final netTotal = _calculateNetTotal();

    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: isDark
          ? const BoxDecoration(color: Color(0xFF0F172A))
          : const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFEEF2FF), Color(0xFFF8FAFC)])),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 10),
            // --- لوغو احترافي بدلاً من كلمة YB بدون الحاجة لإضافة مسارات صور ---
            Container(
              padding: const EdgeInsets.all(35),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [const Color(0xFF1E293B), const Color(0xFF0F172A)]
                      : [Colors.white, const Color(0xFFEEF2FF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(
                    color: isDark
                        ? const Color(0xFFF59E0B)
                        : const Color(0xFF1A237E),
                    width: 3),
                boxShadow: [
                  BoxShadow(
                      color: isDark
                          ? Colors.black54
                          : const Color(0xFF1A237E).withOpacity(0.2),
                      blurRadius: 25,
                      offset: const Offset(0, 10))
                ],
              ),
              child: Column(
                children: [
                  // هذا الكود يستبدل الدائرة والكلمات بصورتك فقط
                  Center(
                    child: Image.asset(
                      'assets/1000526108.png', // تأكد من اسم ملف صورتك هنا
                      width: 200, // يمكنك التحكم في حجمها من هنا
                      height: 200,
                      fit: BoxFit.contain,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(T.s('smartOrganizer'),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: isDark ? Colors.white70 : Colors.black87)),
                  const SizedBox(height: 2),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text(
              globalUserName.isEmpty
                  ? T.s('helloUser')
                  : '${T.s('helloUserName')} $globalUserName',
              style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white : const Color(0xFF1E293B)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withOpacity(0.05)
                    : const Color(0xFF4F46E5).withOpacity(0.05),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: isDark
                        ? Colors.white.withOpacity(0.1)
                        : const Color(0xFF4F46E5).withOpacity(0.2)),
              ),
              child: Column(
                children: [
                  Text(T.s('todayWisdom'),
                      style: TextStyle(
                          fontSize: 12,
                          color: isDark
                              ? const Color(0xFF38BDF8)
                              : const Color(0xFF4F46E5),
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('"$selectedQuote"',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 14,
                          color: isDark ? Colors.white70 : Colors.black87,
                          fontStyle: FontStyle.italic,
                          height: 1.5)),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Row(
              children: [
                Expanded(
                    child: GestureDetector(
                        onTap: () => widget.onNavigate(1),
                        child: _buildStatCard(
                            T.s('practicalTasksCount'),
                            '${globalPracticalTasks.length}',
                            Icons.business_center,
                            const Color(0xFF4F46E5),
                            isDark))),
                const SizedBox(width: 12),
                Expanded(
                    child: GestureDetector(
                        onTap: () => widget.onNavigate(2),
                        child: _buildStatCard(
                            T.s('financialSummary'),
                            '${netTotal.toStringAsFixed(0)}',
                            Icons.account_balance_wallet,
                            const Color(0xFFF43F5E),
                            isDark))),
                const SizedBox(width: 12),
                Expanded(
                    child: GestureDetector(
                        onTap: () => widget.onNavigate(3),
                        child: _buildStatCard(
                            T.s('notesCount'),
                            '${globalNotes.length}',
                            Icons.note_alt,
                            const Color(0xFF10B981),
                            isDark))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(
      String title, String value, IconData icon, Color color, bool isDark) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: isDark ? null : Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: isDark
            ? null
            : [
                BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 10,
                    offset: const Offset(0, 4))
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
              backgroundColor: color.withOpacity(0.1),
              radius: 18,
              child: Icon(icon, color: color, size: 18)),
          const SizedBox(height: 12),
          Text(value,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white : const Color(0xFF1E293B)),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          Text(title,
              style: TextStyle(
                  fontSize: 10,
                  color: isDark ? Colors.white60 : const Color(0xFF64748B)),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ==========================================
// 2. شاشة المهام العملية
// ==========================================
class PracticalTasksTab extends StatefulWidget {
  const PracticalTasksTab({Key? key}) : super(key: key);
  @override
  State<PracticalTasksTab> createState() => _PracticalTasksTabState();
}

class _PracticalTasksTabState extends State<PracticalTasksTab> {
  Timer? _timer;
  final Color navyBlue = const Color(0xFF1A237E);

  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
    _timer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    _timer?.cancel();
    super.dispose();
  }

  void _onLangChange() => setState(() {});

  Map<String, dynamic> _calculateRemainingTime(DateTime deadline) {
    final now = DateTime.now();
    final difference = deadline.difference(now);
    if (difference.isNegative)
      return {'text': T.s('timeExpired'), 'isUrgent': true, 'expired': true};

    final days = difference.inDays;
    final hours = difference.inHours % 24;
    final minutes = difference.inMinutes % 60;
    String text = '';
    if (days > 0) text += '$days ${T.s('daysUnit')} ';
    if (hours > 0) text += '$hours ${T.s('hoursUnit')} ';
    if (minutes > 0 || text.isEmpty) text += '$minutes ${T.s('minutesUnit')}';
    return {
      'text': '${T.s('remaining')} $text',
      'isUrgent': difference.inMinutes <= 60,
      'expired': false
    };
  }

  void _openAddTaskDialog({Map<String, dynamic>? existingTask, int? index}) {
    final titleCtrl = TextEditingController(text: existingTask?['title'] ?? '');
    final descCtrl = TextEditingController(text: existingTask?['desc'] ?? '');
    int durationValue = 1;
    String durationType = T.s('hour');
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => Directionality(
          textDirection: globalLangNotifier.value == 'ar'
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: Text(
                existingTask == null
                    ? T.s('addTaskTitle')
                    : T.s('editTaskTitle'),
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                      controller: titleCtrl,
                      decoration: InputDecoration(labelText: T.s('taskName'))),
                  TextField(
                      controller: descCtrl,
                      decoration: InputDecoration(labelText: T.s('taskDesc'))),
                  const SizedBox(height: 16),
                  Align(
                      alignment: globalLangNotifier.value == 'ar'
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Text(T.s('duration'),
                          style: const TextStyle(
                              fontSize: 12, fontWeight: FontWeight.bold))),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButton<int>(
                          value: durationValue,
                          isExpanded: true,
                          items: List.generate(30, (i) => i + 1)
                              .map((val) => DropdownMenuItem(
                                  value: val, child: Text('$val')))
                              .toList(),
                          onChanged: (val) =>
                              setDialogState(() => durationValue = val ?? 1),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: DropdownButton<String>(
                          value: durationType,
                          isExpanded: true,
                          items: [T.s('hour'), T.s('day')]
                              .map((val) => DropdownMenuItem(
                                  value: val, child: Text(val)))
                              .toList(),
                          onChanged: (val) => setDialogState(
                              () => durationType = val ?? T.s('hour')),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(T.s('cancel'))),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: navyBlue),
                onPressed: () {
                  if (titleCtrl.text.isEmpty) return;
                  final now = DateTime.now();
                  DateTime deadline = durationType == T.s('hour')
                      ? now.add(Duration(hours: durationValue))
                      : now.add(Duration(days: durationValue));
                  setState(() {
                    final taskData = {
                      'title': titleCtrl.text,
                      'desc': descCtrl.text,
                      'deadline': deadline,
                      'dateTime':
                          existingTask?['dateTime'] ?? getCurrentFormattedDate()
                    };
                    if (index == null)
                      globalPracticalTasks.add(taskData);
                    else
                      globalPracticalTasks[index] = taskData;
                  });
                  Navigator.pop(context);
                },
                child: Text(existingTask == null ? T.s('add') : T.s('save'),
                    style: const TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
                backgroundColor: navyBlue,
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: isDark ? 0 : 3),
            icon: const Icon(Icons.add_task, color: Colors.white),
            label: Text(T.s('addTask'),
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            onPressed: () => _openAddTaskDialog(),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: globalPracticalTasks.isEmpty
                ? Center(child: Text(T.s('noTasks')))
                : ListView.builder(
                    itemCount: globalPracticalTasks.length,
                    itemBuilder: (context, index) {
                      final task = globalPracticalTasks[index];
                      final DateTime deadline = task['deadline'];
                      final timeInfo = _calculateRemainingTime(deadline);
                      bool isUrgent = timeInfo['isUrgent'];

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color:
                              isDark ? const Color(0xFF1E293B) : Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: isUrgent
                                  ? Colors.red.shade400
                                  : (isDark
                                      ? Colors.white12
                                      : navyBlue.withOpacity(0.2)),
                              width: isUrgent ? 2 : 1),
                          boxShadow: isDark
                              ? null
                              : [
                                  BoxShadow(
                                      color: isUrgent
                                          ? Colors.red.withOpacity(0.05)
                                          : navyBlue.withOpacity(0.05),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4))
                                ],
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          title: Text(task['title'],
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (task['desc'].toString().isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(task['desc'],
                                    style: TextStyle(
                                        color: isDark
                                            ? Colors.white70
                                            : const Color(0xFF64748B))),
                              ],
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                    color: isUrgent
                                        ? Colors.red.shade50
                                        : (isDark
                                            ? Colors.white10
                                            : const Color(0xFFF1F5F9)),
                                    borderRadius: BorderRadius.circular(8)),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.access_time_filled,
                                        size: 14,
                                        color:
                                            isUrgent ? Colors.red : navyBlue),
                                    const SizedBox(width: 6),
                                    Text(timeInfo['text'],
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: isUrgent
                                                ? Colors.red
                                                : (isDark
                                                    ? Colors.white70
                                                    : navyBlue))),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                  icon: Icon(Icons.edit, color: navyBlue),
                                  onPressed: () => _openAddTaskDialog(
                                      existingTask: task, index: index)),
                              IconButton(
                                icon: const Icon(Icons.delete_outline,
                                    color: Colors.redAccent),
                                onPressed: () =>
                                    setState(() => globalTrash.add({
                                          'type': T.s('typeTask'),
                                          'title': task['title'],
                                          'data': globalPracticalTasks
                                              .removeAt(index)
                                        })),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 3. شاشة المحفظة والمديونيات
// ==========================================
class FinancesTab extends StatefulWidget {
  const FinancesTab({Key? key}) : super(key: key);
  @override
  State<FinancesTab> createState() => _FinancesTabState();
}

class _FinancesTabState extends State<FinancesTab> {
  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
                color: Theme.of(context).brightness == Brightness.dark
                    ? const Color(0xFF1E293B)
                    : Colors.black.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12)),
            child: TabBar(
              indicatorColor: const Color(0xFF4F46E5),
              labelColor: const Color(0xFF4F46E5),
              unselectedLabelColor: Colors.grey,
              indicatorSize: TabBarIndicatorSize.tab,
              tabs: [
                Tab(text: T.s('walletLog')),
                Tab(text: T.s('debtsManage'))
              ],
            ),
          ),
          const Expanded(
              child: TabBarView(children: [WalletView(), DebtsView()])),
        ],
      ),
    );
  }
}

// ---- نافذة المحفظة ----
class WalletView extends StatefulWidget {
  const WalletView({Key? key}) : super(key: key);
  @override
  State<WalletView> createState() => _WalletViewState();
}

class _WalletViewState extends State<WalletView> {
  final _titleController = TextEditingController();
  final _amountController = TextEditingController();
  late String _selectedCategory;
  int? _selectedDebtId;

  @override
  void initState() {
    super.initState();
    _selectedCategory = T.categories[3];
    globalLangNotifier.addListener(_onLangChange);
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() => setState(() {
        _selectedCategory = T.categories[3];
      });

  bool _isCredit(String cat) => cat == T.s('cat1') || cat == T.s('cat2');

  void _addTransaction() {
    if (_titleController.text.trim().isEmpty ||
        _amountController.text.trim().isEmpty) return;
    double? amount = double.tryParse(_amountController.text.trim());
    if (amount == null) return;
    setState(() {
      if (_selectedCategory == T.s('cat3') && _selectedDebtId != null) {
        int di = globalDebts.indexWhere((d) => d['id'] == _selectedDebtId);
        if (di != -1) {
          globalDebts[di]['paid'] += amount;
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(T.s('installmentPaid'))));
        }
      }
      globalExpenses.insert(0, {
        'id': DateTime.now().millisecondsSinceEpoch,
        'title': _titleController.text.trim(),
        'amount': amount,
        'category': _selectedCategory,
        'isCredit': _isCredit(_selectedCategory),
        'date': getCurrentFormattedDate(),
      });
      _titleController.clear();
      _amountController.clear();
      _selectedDebtId = null;
    });
  }

  void _editTransaction(Map<String, dynamic> item, int index) {
    final editTitleCtrl = TextEditingController(text: item['title']);
    final editAmountCtrl =
        TextEditingController(text: item['amount'].toString());
    String editCategory = _selectedCategory;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDS) => Directionality(
          textDirection: globalLangNotifier.value == 'ar'
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: AlertDialog(
            title: Text(T.s('editEntry')),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButton<String>(
                    value: editCategory,
                    isExpanded: true,
                    items: T.categories
                        .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                        .toList(),
                    onChanged: (val) => setDS(() => editCategory = val!),
                  ),
                  TextField(
                      controller: editTitleCtrl,
                      decoration:
                          InputDecoration(labelText: T.s('statementLabel'))),
                  TextField(
                      controller: editAmountCtrl,
                      keyboardType: TextInputType.number,
                      decoration:
                          InputDecoration(labelText: T.s('amountLabel'))),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(T.s('cancel'))),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    globalExpenses[index]['title'] = editTitleCtrl.text;
                    globalExpenses[index]['amount'] =
                        double.tryParse(editAmountCtrl.text) ?? item['amount'];
                    globalExpenses[index]['category'] = editCategory;
                    globalExpenses[index]['isCredit'] = _isCredit(editCategory);
                    globalExpenses[index]['date'] = getCurrentFormattedDate();
                  });
                  Navigator.pop(context);
                },
                child: Text(T.s('save')),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double totalCredit = globalExpenses
        .where((i) => i['isCredit'] == true)
        .fold(0.0, (s, i) => s + i['amount']);
    double totalDebit = globalExpenses
        .where((i) => i['isCredit'] == false)
        .fold(0.0, (s, i) => s + i['amount']);
    double netBalance = totalCredit - totalDebit;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    const mainColor = Color(0xFF4F46E5);

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: isDark
                        ? [const Color(0xFF0F172A), mainColor.withOpacity(0.25)]
                        : [Colors.white, mainColor.withOpacity(0.15)]),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: mainColor.withOpacity(0.3))),
            child: Column(
              children: [
                Text(T.s('netBalance'),
                    style: TextStyle(
                        color: isDark ? Colors.white70 : Colors.black87,
                        fontSize: 13,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('${netBalance.toStringAsFixed(2)} ${T.s('currency')}',
                    style: TextStyle(
                        color:
                            netBalance >= 0 ? Colors.green : Colors.redAccent,
                        fontSize: 24,
                        fontWeight: FontWeight.bold)),
                const Divider(height: 20, color: Colors.black12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(children: [
                      Text(T.s('credit'),
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                      Text('+${totalCredit.toStringAsFixed(1)}',
                          style: const TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontSize: 14))
                    ]),
                    Column(children: [
                      Text(T.s('debit'),
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                      Text('-${totalDebit.toStringAsFixed(1)}',
                          style: const TextStyle(
                              color: Colors.redAccent,
                              fontWeight: FontWeight.bold,
                              fontSize: 14))
                    ]),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: isDark
                    ? const Color(0xFF1E293B)
                    : Colors.black.withOpacity(0.03),
                borderRadius: BorderRadius.circular(14)),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(T.s('type'),
                        style: const TextStyle(
                            fontSize: 12, fontWeight: FontWeight.bold)),
                    Expanded(
                      child: DropdownButton<String>(
                        value: _selectedCategory,
                        isExpanded: true,
                        underline: const SizedBox(),
                        dropdownColor: Theme.of(context).cardColor,
                        items: T.categories
                            .map((c) => DropdownMenuItem(
                                value: c,
                                child: Text(c,
                                    style: const TextStyle(fontSize: 12))))
                            .toList(),
                        onChanged: (val) => setState(() {
                          _selectedCategory = val!;
                          if (_selectedCategory != T.s('cat3'))
                            _selectedDebtId = null;
                        }),
                      ),
                    ),
                  ],
                ),
                if (_selectedCategory == T.s('cat3') && globalDebts.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      children: [
                        Text(T.s('debtLabel'),
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.bold)),
                        Expanded(
                          child: DropdownButton<int>(
                            value: _selectedDebtId,
                            isExpanded: true,
                            hint: Text(T.s('debtHint'),
                                style: const TextStyle(fontSize: 12)),
                            items: globalDebts
                                .map((d) => DropdownMenuItem<int>(
                                    value: d['id'],
                                    child: Text(d['title'],
                                        style: const TextStyle(fontSize: 12))))
                                .toList(),
                            onChanged: (val) => setState(() {
                              _selectedDebtId = val;
                              if (_titleController.text.isEmpty)
                                _titleController.text =
                                    '${T.s('installmentPrefix')} ${globalDebts.firstWhere((d) => d['id'] == val)['title']}';
                            }),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                        flex: 2,
                        child: TextField(
                            controller: _titleController,
                            decoration: InputDecoration(
                                hintText: T.s('statement'),
                                hintStyle: const TextStyle(fontSize: 12),
                                filled: true,
                                fillColor: isDark
                                    ? const Color(0xFF0F172A)
                                    : Colors.white,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none)))),
                    const SizedBox(width: 6),
                    Expanded(
                        flex: 1,
                        child: TextField(
                            controller: _amountController,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            decoration: InputDecoration(
                                hintText: T.s('amount'),
                                hintStyle: const TextStyle(fontSize: 12),
                                filled: true,
                                fillColor: isDark
                                    ? const Color(0xFF0F172A)
                                    : Colors.white,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none)))),
                    const SizedBox(width: 6),
                    IconButton(
                        style: IconButton.styleFrom(backgroundColor: mainColor),
                        icon: const Icon(Icons.add, color: Colors.white),
                        onPressed: _addTransaction),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              itemCount: globalExpenses.length,
              itemBuilder: (context, index) {
                final item = globalExpenses[index];
                final isCredit = item['isCredit'] ?? false;
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                        backgroundColor: isCredit
                            ? Colors.green.withOpacity(0.1)
                            : Colors.redAccent.withOpacity(0.1),
                        child: Icon(
                            isCredit
                                ? Icons.arrow_downward
                                : Icons.arrow_upward,
                            color: isCredit ? Colors.green : Colors.redAccent,
                            size: 18)),
                    title: Text(item['title'],
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${item['category']} | ${item['date']}',
                        style:
                            const TextStyle(color: Colors.grey, fontSize: 10)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('${isCredit ? "+" : "-"}${item['amount']}',
                            style: TextStyle(
                                color:
                                    isCredit ? Colors.green : Colors.redAccent,
                                fontWeight: FontWeight.bold,
                                fontSize: 14)),
                        IconButton(
                            icon: const Icon(Icons.edit,
                                color: Colors.blue, size: 18),
                            onPressed: () => _editTransaction(item, index)),
                        IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: Colors.redAccent, size: 18),
                            onPressed: () => setState(() => globalTrash.add({
                                  'type': T.s('typeExpense'),
                                  'title': item['title'],
                                  'data': globalExpenses.removeAt(index)
                                }))),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ---- نافذة المديونيات ----
class DebtsView extends StatefulWidget {
  const DebtsView({Key? key}) : super(key: key);
  @override
  State<DebtsView> createState() => _DebtsViewState();
}

class _DebtsViewState extends State<DebtsView> {
  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() => setState(() {});

  void _openAddDebtDialog({Map<String, dynamic>? existingDebt, int? index}) {
    final titleCtrl = TextEditingController(text: existingDebt?['title'] ?? '');
    final totalCtrl =
        TextEditingController(text: existingDebt?['total']?.toString() ?? '');
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: globalLangNotifier.value == 'ar'
            ? TextDirection.rtl
            : TextDirection.ltr,
        child: AlertDialog(
          title: Text(
              existingDebt == null ? T.s('addDebtTitle') : T.s('editDebtTitle'),
              style: const TextStyle(fontSize: 16)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                    controller: titleCtrl,
                    decoration: InputDecoration(labelText: T.s('debtName'))),
                TextField(
                    controller: totalCtrl,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: T.s('debtTotal'))),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(T.s('cancel'))),
            ElevatedButton(
              onPressed: () {
                if (titleCtrl.text.isEmpty || totalCtrl.text.isEmpty) return;
                double? total = double.tryParse(totalCtrl.text);
                if (total == null) return;
                setState(() {
                  if (index == null) {
                    globalDebts.add({
                      'id': DateTime.now().millisecondsSinceEpoch,
                      'title': titleCtrl.text,
                      'total': total,
                      'paid': 0.0,
                      'date': getCurrentFormattedDate()
                    });
                  } else {
                    globalDebts[index]['title'] = titleCtrl.text;
                    globalDebts[index]['total'] = total;
                  }
                });
                Navigator.pop(context);
              },
              child: Text(existingDebt == null ? T.s('add') : T.s('save')),
            ),
          ],
        ),
      ),
    );
  }

  void _payInstallmentDialog(int index) {
    final amountCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: globalLangNotifier.value == 'ar'
            ? TextDirection.rtl
            : TextDirection.ltr,
        child: AlertDialog(
          title:
              Text('${T.s('payInstallment')} ${globalDebts[index]['title']}'),
          content: SingleChildScrollView(
            child: TextField(
                controller: amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: T.s('payAmountNow'))),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(T.s('cancel'))),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              onPressed: () {
                if (amountCtrl.text.isEmpty) return;
                double? paidAmount = double.tryParse(amountCtrl.text);
                if (paidAmount == null || paidAmount <= 0) return;
                setState(() {
                  globalDebts[index]['paid'] += paidAmount;
                  globalExpenses.insert(0, {
                    'id': DateTime.now().millisecondsSinceEpoch,
                    'title':
                        '${T.s('installmentPayPrefix')} ${globalDebts[index]['title']}',
                    'amount': paidAmount,
                    'category': T.s('cat3'),
                    'isCredit': false,
                    'date': getCurrentFormattedDate(),
                  });
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text(T.s('paySuccess'))));
              },
              child: Text(T.s('confirmPay'),
                  style: const TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double totalDebts = globalDebts.fold(0.0, (s, i) => s + i['total']);
    double totalPaid = globalDebts.fold(0.0, (s, i) => s + i['paid']);
    double remainingDebts = totalDebts - totalPaid;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: isDark ? const Color(0xFF1E293B) : Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.redAccent.withOpacity(0.3))),
            child: Column(
              children: [
                Text(T.s('totalRemaining'),
                    style: TextStyle(
                        color: isDark ? Colors.white70 : Colors.black87,
                        fontSize: 13,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('${remainingDebts.toStringAsFixed(2)} ${T.s('currency')}',
                    style: const TextStyle(
                        color: Colors.redAccent,
                        fontSize: 24,
                        fontWeight: FontWeight.bold)),
                const Divider(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(children: [
                      Text(T.s('totalDebts'),
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                      Text('${totalDebts.toStringAsFixed(1)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14))
                    ]),
                    Column(children: [
                      Text(T.s('totalPaid'),
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                      Text('${totalPaid.toStringAsFixed(1)}',
                          style: const TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontSize: 14))
                    ]),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF43F5E),
                minimumSize: const Size(double.infinity, 48)),
            icon: const Icon(Icons.add, color: Colors.white),
            label: Text(T.s('addDebt'),
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            onPressed: () => _openAddDebtDialog(),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: globalDebts.length,
              itemBuilder: (context, index) {
                final debt = globalDebts[index];
                double total = debt['total'];
                double paid = debt['paid'];
                double remain = total - paid;
                double progress =
                    total > 0 ? (paid / total).clamp(0.0, 1.0) : 0;
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                          color:
                              isDark ? Colors.white12 : Colors.grey.shade200)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(debt['title'],
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16)),
                            Row(
                              children: [
                                IconButton(
                                    icon: const Icon(Icons.edit,
                                        color: Colors.blue, size: 20),
                                    onPressed: () => _openAddDebtDialog(
                                        existingDebt: debt, index: index),
                                    padding: EdgeInsets.zero,
                                    constraints: const BoxConstraints()),
                                const SizedBox(width: 12),
                                IconButton(
                                    icon: const Icon(Icons.delete_outline,
                                        color: Colors.redAccent, size: 20),
                                    onPressed: () =>
                                        setState(() => globalTrash.add({
                                              'type': T.s('typeDebt'),
                                              'title': debt['title'],
                                              'data':
                                                  globalDebts.removeAt(index)
                                            })),
                                    padding: EdgeInsets.zero,
                                    constraints: const BoxConstraints()),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        LinearProgressIndicator(
                            value: progress,
                            backgroundColor:
                                isDark ? Colors.white10 : Colors.grey.shade200,
                            color: progress >= 1.0
                                ? Colors.green
                                : Colors.redAccent,
                            minHeight: 8),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                                '${T.s('debtRemain')} ${remain.toStringAsFixed(1)}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.redAccent)),
                            Text(
                                '${T.s('debtPaid')} ${paid.toStringAsFixed(1)}',
                                style: const TextStyle(color: Colors.green)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (remain > 0)
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green.withOpacity(0.1),
                                elevation: 0,
                                minimumSize: const Size(double.infinity, 36)),
                            onPressed: () => _payInstallmentDialog(index),
                            child: Text(T.s('payNow'),
                                style: const TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold)),
                          )
                        else
                          Container(
                              width: double.infinity,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Text(T.s('debtCleared'),
                                  style: const TextStyle(
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold))),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 4. شاشة الملاحظات
// ==========================================
class NotesTab extends StatefulWidget {
  const NotesTab({Key? key}) : super(key: key);
  @override
  State<NotesTab> createState() => _NotesTabState();
}

class _NotesTabState extends State<NotesTab> {
  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() => setState(() {});

  List<Color> _getPalette(bool isDark) {
    if (isDark)
      return [
        Colors.blueGrey.shade100,
        Colors.red.shade100,
        Colors.teal.shade100,
        Colors.orange.shade100,
        Colors.purple.shade100
      ];
    return [
      const Color(0xFF1E293B),
      Colors.red.shade900,
      Colors.teal.shade900,
      Colors.orange.shade900,
      Colors.purple.shade900
    ];
  }

  Future<String?> _showSetPasswordDialog() async {
    final p1 = TextEditingController();
    final p2 = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: globalLangNotifier.value == 'ar'
            ? TextDirection.rtl
            : TextDirection.ltr,
        child: AlertDialog(
          title: Text(T.s('setPassword'), style: const TextStyle(fontSize: 16)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                    controller: p1,
                    obscureText: true,
                    decoration: InputDecoration(hintText: T.s('password'))),
                TextField(
                    controller: p2,
                    obscureText: true,
                    decoration:
                        InputDecoration(hintText: T.s('confirmPassword'))),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(T.s('cancel'))),
            ElevatedButton(
              onPressed: () {
                if (p1.text.isEmpty) return;
                if (p1.text == p2.text) {
                  Navigator.pop(ctx, p1.text);
                } else {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                      SnackBar(content: Text(T.s('passwordMismatch'))));
                }
              },
              child: Text(T.s('confirm')),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> _showUnlockDialog(String correctPassword) async {
    final p = TextEditingController();
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => Directionality(
            textDirection: globalLangNotifier.value == 'ar'
                ? TextDirection.rtl
                : TextDirection.ltr,
            child: AlertDialog(
              title:
                  Text(T.s('noteLocked'), style: const TextStyle(fontSize: 16)),
              content: SingleChildScrollView(
                child: TextField(
                    controller: p,
                    obscureText: true,
                    autofocus: true,
                    decoration:
                        InputDecoration(hintText: T.s('enterPassword'))),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: Text(T.s('cancel'))),
                ElevatedButton(
                  onPressed: () {
                    if (p.text == correctPassword) {
                      Navigator.pop(ctx, true);
                    } else {
                      ScaffoldMessenger.of(ctx).showSnackBar(
                          SnackBar(content: Text(T.s('wrongPassword'))));
                    }
                  },
                  child: Text(T.s('open')),
                ),
              ],
            ),
          ),
        ) ??
        false;
  }

  void _openNoteDialog({Map<String, dynamic>? existingNote, int? index}) {
    final bool isAppDark = Theme.of(context).brightness == Brightness.dark;
    final List<Color> currentPalette = _getPalette(isAppDark);
    int selectedColorIndex = existingNote?['colorIndex'] ?? 0;
    final titleCtrl = TextEditingController(text: existingNote?['title'] ?? '');
    final contentCtrl =
        TextEditingController(text: existingNote?['content'] ?? '');
    bool isImportant = existingNote?['important'] ?? false;
    bool isLocked = existingNote?['isLocked'] ?? false;
    String password = existingNote?['password'] ?? '';
    Color textColor = isAppDark ? Colors.black87 : Colors.white;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => Directionality(
          textDirection: globalLangNotifier.value == 'ar'
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: AlertDialog(
            backgroundColor: currentPalette[selectedColorIndex],
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                    existingNote == null
                        ? T.s('newNoteTitle')
                        : T.s('editNoteTitle'),
                    style: TextStyle(color: textColor, fontSize: 16)),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(isLocked ? Icons.lock : Icons.lock_open,
                          color: textColor),
                      onPressed: () async {
                        if (isLocked) {
                          setDialogState(() {
                            isLocked = false;
                            password = '';
                          });
                        } else {
                          final pwd = await _showSetPasswordDialog();
                          if (pwd != null)
                            setDialogState(() {
                              isLocked = true;
                              password = pwd;
                            });
                        }
                      },
                    ),
                    IconButton(
                        icon: Icon(isImportant ? Icons.star : Icons.star_border,
                            color: Colors.amber),
                        onPressed: () =>
                            setDialogState(() => isImportant = !isImportant)),
                  ],
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                      controller: titleCtrl,
                      decoration: InputDecoration(
                          hintText: T.s('noteTitle'),
                          hintStyle:
                              TextStyle(color: textColor.withOpacity(0.6)),
                          border: InputBorder.none),
                      style: TextStyle(
                          color: textColor, fontWeight: FontWeight.bold)),
                  Divider(color: textColor.withOpacity(0.2)),
                  TextField(
                      controller: contentCtrl,
                      maxLines: 5,
                      decoration: InputDecoration(
                          hintText: T.s('noteContent'),
                          hintStyle:
                              TextStyle(color: textColor.withOpacity(0.6)),
                          border: InputBorder.none),
                      style: TextStyle(color: textColor)),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                        currentPalette.length,
                        (i) => GestureDetector(
                              onTap: () =>
                                  setDialogState(() => selectedColorIndex = i),
                              child: Container(
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 4),
                                width: 26,
                                height: 26,
                                decoration: BoxDecoration(
                                    color: currentPalette[i],
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: selectedColorIndex == i
                                            ? textColor
                                            : Colors.transparent,
                                        width: 2)),
                              ),
                            )),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(T.s('cancel'),
                      style: TextStyle(color: textColor.withOpacity(0.7)))),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF59E0B)),
                onPressed: () {
                  if (titleCtrl.text.isEmpty && contentCtrl.text.isEmpty)
                    return;
                  setState(() {
                    final noteData = {
                      'title': titleCtrl.text,
                      'content': contentCtrl.text,
                      'colorIndex': selectedColorIndex,
                      'important': isImportant,
                      'dateTime': existingNote?['dateTime'] ??
                          getCurrentFormattedDate(),
                      'isLocked': isLocked,
                      'password': password
                    };
                    if (index == null)
                      globalNotes.insert(0, noteData);
                    else
                      globalNotes[index] = noteData;
                  });
                  Navigator.pop(context);
                },
                child: Text(T.s('save'),
                    style: const TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _sortNotes() {
    setState(() {
      globalNotes.sort((a, b) {
        if (a['important'] == b['important']) return 0;
        return (a['important'] == true) ? -1 : 1;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool isAppDark = Theme.of(context).brightness == Brightness.dark;
    final List<Color> currentPalette = _getPalette(isAppDark);
    Color textColor = isAppDark ? Colors.black87 : Colors.white;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF59E0B),
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                  icon: const Icon(Icons.edit_note, color: Colors.black),
                  label: Text(T.s('newNote'),
                      style: const TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold)),
                  onPressed: () => _openNoteDialog(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                  tooltip: T.s('sortByImportance'),
                  style: IconButton.styleFrom(
                      backgroundColor: Theme.of(context).cardColor),
                  icon: const Icon(Icons.sort),
                  onPressed: _sortNotes),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10),
              itemCount: globalNotes.length,
              itemBuilder: (context, index) {
                final note = globalNotes[index];
                final bool isLocked = note['isLocked'] ?? false;
                final int colorIdx = note['colorIndex'] ?? 0;
                final Color noteColor = currentPalette[colorIdx];

                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: noteColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: note['important'] == true
                            ? Colors.amber
                            : textColor.withOpacity(0.1),
                        width: note['important'] == true ? 2 : 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                              child: Text(note['title'],
                                  style: TextStyle(
                                      color: textColor,
                                      fontWeight: FontWeight.bold),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis)),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (isLocked)
                                Padding(
                                    padding: const EdgeInsets.only(left: 4),
                                    child: Icon(Icons.lock,
                                        size: 16,
                                        color: textColor.withOpacity(0.7))),
                              if (note['important'] == true)
                                const Icon(Icons.star,
                                    size: 16, color: Colors.amber),
                            ],
                          ),
                        ],
                      ),
                      Divider(color: textColor.withOpacity(0.2)),
                      Expanded(
                          child: isLocked
                              ? Center(
                                  child: Icon(Icons.lock,
                                      color: textColor.withOpacity(0.3),
                                      size: 40))
                              : Text(note['content'],
                                  style: TextStyle(
                                      color: textColor.withOpacity(0.8),
                                      fontSize: 12),
                                  overflow: TextOverflow.fade)),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(note['dateTime'].toString().split('-')[0],
                              style: TextStyle(
                                  color: textColor.withOpacity(0.5),
                                  fontSize: 8)),
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () async {
                                  if (isLocked) {
                                    bool unlocked = await _showUnlockDialog(
                                        note['password']);
                                    if (!unlocked) return;
                                  }
                                  _openNoteDialog(
                                      existingNote: note, index: index);
                                },
                                child: Icon(Icons.edit,
                                    size: 18,
                                    color: isAppDark
                                        ? Colors.blue.shade800
                                        : Colors.blue.shade200),
                              ),
                              const SizedBox(width: 8),
                              GestureDetector(
                                onTap: () => setState(() => globalTrash.add({
                                      'type': T.s('typeNote'),
                                      'title': note['title'],
                                      'data': globalNotes.removeAt(index)
                                    })),
                                child: const Icon(Icons.delete_sweep,
                                    size: 18, color: Colors.redAccent),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 5. شاشة سلة المهملات
// ==========================================
class TrashTab extends StatefulWidget {
  const TrashTab({Key? key}) : super(key: key);
  @override
  State<TrashTab> createState() => _TrashTabState();
}

class _TrashTabState extends State<TrashTab> {
  @override
  void initState() {
    super.initState();
    globalLangNotifier.addListener(_onLangChange);
  }

  @override
  void dispose() {
    globalLangNotifier.removeListener(_onLangChange);
    super.dispose();
  }

  void _onLangChange() => setState(() {});

  String _getLocalizedType(String type) {
    if (type == 'مهمة عملية' ||
        type == 'Tâche pratique' ||
        type == 'Practical Task') return T.s('typeTask');
    if (type == 'ملاحظة' || type == 'Note') return T.s('typeNote');
    if (type == 'عملية مالية' ||
        type == 'Transaction financière' ||
        type == 'Financial Transaction') return T.s('typeExpense');
    if (type == 'مديونية' || type == 'Dette' || type == 'Debt')
      return T.s('typeDebt');
    return type;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          if (globalTrash.isNotEmpty)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                icon: const Icon(Icons.delete_forever, color: Colors.red),
                label: Text(T.s('emptyTrash'),
                    style: const TextStyle(color: Colors.red)),
                onPressed: () => setState(() => globalTrash.clear()),
              ),
            ),
          Expanded(
            child: globalTrash.isEmpty
                ? Center(child: Text(T.s('trashEmpty')))
                : ListView.builder(
                    itemCount: globalTrash.length,
                    itemBuilder: (context, index) {
                      final item = globalTrash[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(item['title'] ?? T.s('noTitle')),
                          subtitle: Text(
                              '${T.s('itemType')} ${_getLocalizedType(item['type'])}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.restore,
                                    color: Colors.green),
                                tooltip: T.s('restore'),
                                onPressed: () {
                                  setState(() {
                                    final restoredData = item['data'];
                                    final type = item['type'];
                                    if (type == 'مهمة عملية' ||
                                        type == 'Tâche pratique' ||
                                        type == 'Practical Task')
                                      globalPracticalTasks.add(restoredData);
                                    else if (type == 'ملاحظة' || type == 'Note')
                                      globalNotes.add(restoredData);
                                    else if (type == 'عملية مالية' ||
                                        type == 'Transaction financière' ||
                                        type == 'Financial Transaction')
                                      globalExpenses.add(restoredData);
                                    else if (type == 'مديونية' ||
                                        type == 'Dette' ||
                                        type == 'Debt')
                                      globalDebts.add(restoredData);
                                    globalTrash.removeAt(index);
                                  });
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                          content:
                                              Text(T.s('restoreSuccess'))));
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_forever,
                                    color: Colors.redAccent),
                                tooltip: T.s('deletePermanent'),
                                onPressed: () =>
                                    setState(() => globalTrash.removeAt(index)),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
